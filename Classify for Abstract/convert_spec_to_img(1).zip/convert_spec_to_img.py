def convert_spectra_to_images(X_all, image_width, image_height):
 
  y_min = -1500 # min amplitude of spectrum
  y_max = 29000 # max amplitude of spectrum
  
  X_allimg = np.zeros((X_all.shape[0], image_height, image_width))

  for i in np.arange(X_all.shape[0]):
    I = np.ones((image_height, image_width))
    spec = X_all[i, :]

    for j in np.arange(len(spec)):
      x_spec = j
      y_spec = spec[j]

      x_min = 0
      x_max = len(spec)
    
      x_img = np.int(np.round((x_spec-x_min)/(x_max-x_min)*(image_width-1)))
      y_img = np.int(np.round((image_height-1) - (y_spec-y_min)/(y_max-y_min)*(image_height-1)))
      padding = 0
      I[y_img-padding:y_img+padding+1, x_img-padding:x_img+padding+1] = 0

    X_allimg[i, :, :] = I
    print("Converted spectrum ", i)
  return X_allimg

data_train = np.load('dataset_train.npz')
X_train = convert_spectra_to_images(data_train['X_all'], 128, 128)
y_train = np.ravel(data_train['y_all'])

data_test = np.load('dataset_test.npz')
X_test = convert_spectra_to_images(data_test['X_all'], 128, 128)
y_test = np.ravel(data_test['y_all'])